/**
 * ENRICH — fetch a company's website and pull out:
 *   • a business description (meta description + visible text)
 *   • a published contact email
 *
 * We only ever use addresses the company publishes themselves.
 * No pattern-guessing (firstname.lastname@) — it bounces and burns
 * sender reputation.
 */

import CONFIG from "../config.js";
import { safeFetch, robotsAllows, htmlToText, domainOf } from "./util.js";

const CONTACT_PATHS = ["/", "/contact", "/contact-us", "/contactus", "/about", "/about-us"];

const EMAIL_RE = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;

// Addresses we never want to use as a target
const JUNK_EMAIL_PATTERNS = [
  /^(no-?reply|donot-?reply|postmaster|abuse|webmaster|privacy|dpo)@/i,
  /\.(png|jpe?g|gif|svg|webp|css|js)$/i,
  /^[a-f0-9]{16,}@/i, // cloudflare obfuscation artefacts
  /@(sentry|wixpress|example|domain|yourdomain|email)\./i,
];

// Preference order — generic business inboxes are safest for cold outreach
const EMAIL_PRIORITY = [
  /^info@/i, /^enquiry@/i, /^enquiries@/i, /^contact@/i, /^sales@/i,
  /^marketing@/i, /^hr@/i, /^admin@/i, /^office@/i,
];

function pickBestEmail(candidates, companyDomain) {
  const cleaned = [...new Set(candidates.map((e) => e.toLowerCase().trim()))]
    .filter((e) => !JUNK_EMAIL_PATTERNS.some((re) => re.test(e)))
    .filter((e) => {
      const d = e.split("@")[1];
      if (!d) return false;
      if (CONFIG.safety.blockedDomains.includes(d)) return false;
      // must be on the company's own domain (or a subdomain of it)
      if (companyDomain) return d === companyDomain || d.endsWith("." + companyDomain);
      return true;
    });

  if (!cleaned.length) return null;
  for (const re of EMAIL_PRIORITY) {
    const hit = cleaned.find((e) => re.test(e));
    if (hit) return hit;
  }
  return cleaned[0];
}

function extractMetaDescription(html) {
  const m =
    html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i) ||
    html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']description["']/i) ||
    html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i);
  return m ? m[1].trim() : null;
}

function extractTitle(html) {
  const m = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  return m ? m[1].trim() : null;
}

/**
 * @returns {Promise<{ok:boolean, description?:string, corpus?:string,
 *                     email?:string, title?:string, error?:string}>}
 */
export async function enrichCompany(company) {
  if (!company.website) return { ok: false, error: "no website on record" };

  const companyDomain = domainOf(company.website);
  let corpus = "";
  let description = null;
  let title = null;
  const emails = [];
  let anySuccess = false;

  for (const path of CONTACT_PATHS) {
    let url;
    try {
      url = new URL(path, company.website).toString();
    } catch {
      continue;
    }

    if (!(await robotsAllows(company.website, path))) continue;

    const res = await safeFetch(url);
    if (!res.ok) continue;
    anySuccess = true;

    if (!description) description = extractMetaDescription(res.text);
    if (!title) title = extractTitle(res.text);

    // Emails can appear in raw HTML (mailto:) or in visible text
    const found = res.text.match(EMAIL_RE);
    if (found) emails.push(...found);

    corpus += " " + htmlToText(res.text, 60000);

    // Enough signal collected — stop fetching to save CPU and be polite
    if (corpus.length > 8000 && emails.length > 0) break;
  }

  if (!anySuccess) return { ok: false, error: "all page fetches failed" };

  corpus = corpus.replace(/\s+/g, " ").trim().slice(0, 12000);

  if (!description) {
    description = corpus.slice(0, 400);
  }

  return {
    ok: true,
    description: description.slice(0, 600),
    corpus,
    title,
    email: pickBestEmail(emails, companyDomain),
  };
}
