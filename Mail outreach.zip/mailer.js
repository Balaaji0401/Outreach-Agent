/**
 * MAILER — Resend HTTP API.
 *
 * Why Resend and not Cloudflare Email Service:
 *   Cloudflare Email Service sends free ONLY to verified destination
 *   addresses in your own account. Sending to arbitrary recipients
 *   (our prospects) requires the Workers Paid plan at $5/mo.
 *   Resend's free tier is 3,000/month and 100/day with no base plan.
 *
 * Requires: neurosaur.in verified in Resend with SPF, DKIM and DMARC.
 */

import CONFIG from "../config.js";

const RESEND_ENDPOINT = "https://api.resend.com/emails";

async function send(apiKey, payload) {
  const res = await fetch(RESEND_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* non-JSON error body */
  }

  if (!res.ok) {
    return { ok: false, error: json?.message || `HTTP ${res.status}: ${text.slice(0, 300)}` };
  }
  return { ok: true, id: json?.id || null };
}

/** Internal digest to the reviewer inbox. */
export async function sendReviewEmail(apiKey, { subject, html }) {
  return send(apiKey, {
    from: `${CONFIG.review.fromName} <${CONFIG.review.fromEmail}>`,
    to: [CONFIG.review.inbox],
    subject,
    html,
  });
}

/** Outbound email to a prospect. */
export async function sendProspectEmail(apiKey, { to, subject, text }) {
  if (!CONFIG.safety.sendingEnabled) {
    return { ok: false, error: "sending disabled by config.safety.sendingEnabled" };
  }

  const domain = String(to).split("@")[1]?.toLowerCase();
  if (!domain || CONFIG.safety.blockedDomains.includes(domain)) {
    return { ok: false, error: `blocked or invalid recipient domain: ${domain}` };
  }

  return send(apiKey, {
    from: `${CONFIG.outbound.fromName} <${CONFIG.outbound.fromEmail}>`,
    to: [to],
    reply_to: CONFIG.outbound.replyTo,
    subject,
    text, // plain text sends land in the inbox far more reliably than HTML
  });
}
