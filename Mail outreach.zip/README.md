# Neurosaur Outreach Engine

Daily lead-discovery and human-approved cold outreach for Neurosaur AI Academy.
Runs entirely on Cloudflare's free tier.

---

## How it works

```
CRON (09:00 IST, weekdays)
   │
   ├─ 1. Enrich  — fetch each company's website, pull description + published email
   ├─ 2. Score   — heuristic AI-maturity score (LOW maturity = HIGH opportunity)
   ├─ 3. Select  — top 5 eligible, not contacted in the last 180 days
   ├─ 4. Write   — Workers AI generates one tailored email per company
   ├─ 5. Store   — saved as drafts, status = pending_review
   └─ 6. Notify  — ONE digest email to info@neurosaur.in

REVIEWER clicks a button in that email
   │
   ├─ Approve → sends to the prospect immediately
   ├─ Modify  → opens an editor; save & resubmit, or save & send now
   └─ Deny    → company blocked permanently
```

Nothing is ever sent to a prospect without a human clicking Approve.

---

## Cost

| Component | Free tier | Our usage |
|---|---|---|
| Workers | 100k requests/day | ~20/day |
| Workers AI | 10,000 neurons/day | ~3,000 (5 emails) |
| D1 | 5 GB, 5M reads/day | negligible |
| Cron Triggers | included | 1/day |
| Resend | 3,000/month, 100/day | ~10/day |

**Total: ₹0/month.**

> Cloudflare Email Service is *not* used for prospect sends — it only sends free to
> verified addresses in your own account; arbitrary recipients need Workers Paid ($5/mo).
> Resend's free tier has no such restriction.

---

## Setup

### 1. Install

```bash
npm install
npx wrangler login
```

### 2. Create the database

```bash
npx wrangler d1 create neurosaur_outreach
```

Copy the returned `database_id` into `wrangler.toml`.

```bash
npm run db:init
```

### 3. Resend

1. Sign up at resend.com (free)
2. Add and verify the domain `neurosaur.in`
3. **Add the SPF, DKIM and DMARC DNS records Resend gives you** — in Cloudflare DNS.
   This is mandatory. Without it your mail lands in spam and your domain reputation suffers.
4. Create an API key

### 4. Secrets

```bash
npx wrangler secret put RESEND_API_KEY
npx wrangler secret put REVIEW_SECRET     # any long random string
```

Generate a secret: `openssl rand -hex 32`

### 5. Deploy

```bash
npm run deploy
```

Take the deployed URL and put it in `wrangler.toml` as `PUBLIC_BASE_URL`, then
deploy once more. The approve/deny links are built from this value.

### 6. Load target companies

Edit `seed-companies.json`, then:

```bash
curl -X POST https://YOUR-WORKER.workers.dev/admin/seed \
  -H "X-Admin-Token: YOUR_REVIEW_SECRET" \
  -H "Content-Type: application/json" \
  --data @seed-companies.json
```

Duplicate domains are skipped automatically, so you can re-run this safely.

### 7. Test

```bash
curl -X POST https://YOUR-WORKER.workers.dev/admin/run \
  -H "X-Admin-Token: YOUR_REVIEW_SECRET"
```

Check info@neurosaur.in for the digest.

---

## Where to find target companies

The engine enriches and scores whatever you seed. Good free sources for
Chennai manufacturers:

- **TANSTIA** — Tamil Nadu Small and Tiny Industries Association member directory
- **CII Tamil Nadu** — member listings
- **Udyam / MSME registry** — `udyamregistration.gov.in`
- **SIDCO / SIPCOT** industrial estate directories
- **AMTMA, ACMA** — machine tool and auto component associations
- Trade show exhibitor lists (IMTEX, ACMA Automechanika)

Export name + website + sector into `seed-companies.json`. A few hundred entries
lasts months at 5/day, and hand-picked lists convert far better than scraped ones.

---

## Changing behaviour

Everything tunable is in **`config.js`**:

| What | Where |
|---|---|
| Reviewer inbox, sender addresses | `review`, `outbound` |
| Candidates per day | `pipeline.candidatesPerDay` |
| Re-contact cooldown | `pipeline.recontactCooldownDays` |
| Scoring keywords and threshold | `targeting` |
| Programmes, proof points, CTA | `company` |
| Email tone and hard rules | `generation.rules` |
| Kill switch | `safety.sendingEnabled` |

Schedule is in `wrangler.toml` under `[triggers] crons` (UTC — IST is UTC+5:30).

Redeploy after any change: `npm run deploy`

---

## Operating notes

**Kill switch.** Set `safety.sendingEnabled = false` and redeploy. Drafts still
generate and review emails still arrive, so you can see what *would* have sent,
but no prospect email goes out.

**Deliverability.** 5/day with human approval is a healthy pattern. Keep it that
way — raising volume sharply, especially before the domain has warmed up, is the
fastest route to a spam-folder reputation. Watch bounces in the Resend dashboard
and remove bad addresses.

**Unsubscribes.** Replies go to info@neurosaur.in. When someone asks to be removed,
set that company's status to `unsubscribed`:

```bash
npx wrangler d1 execute neurosaur_outreach --remote \
  --command "UPDATE companies SET status='unsubscribed' WHERE contact_email='them@example.com'"
```

**Compliance.** The engine only uses contact addresses companies publish on their
own websites, respects robots.txt, identifies itself in the user agent, and puts an
opt-out line plus a postal address in every email. Worth having someone confirm this
meets your obligations under India's DPDP Act before the first send.

**Monitoring.** `npm run tail` streams live logs. `/dashboard` shows the last 100
drafts and their status.

---

## Endpoints

| Route | Method | Purpose |
|---|---|---|
| `/health` | GET | Liveness check |
| `/review/approve` | GET | Approve and send (signed link) |
| `/review/modify` | GET/POST | Edit form / save (signed link) |
| `/review/deny` | GET | Block company (signed link) |
| `/dashboard` | GET | Recent drafts |
| `/admin/seed` | POST | Bulk import companies (admin token) |
| `/admin/run` | POST | Trigger a run manually (admin token) |

Review links are HMAC-signed against `REVIEW_SECRET` and expire after 72 hours
(`config.review.linkValidHours`).

---

## Things to watch

**The dashboard is unauthenticated.** It only exposes company names and draft
subjects, but put Cloudflare Access in front of the Worker if that matters.

**Workers AI neuron budget.** 10,000/day. Five emails uses roughly 3,000. Do not
switch `generation.model` to a 70B model without moving to Workers Paid — it will
exhaust the allocation in two or three calls.

**Scoring is heuristic, not intelligent.** It reads keywords. Review the score
detail in the `companies.score_detail` column occasionally and tune the keyword
lists in `config.js` as you learn what converts.
