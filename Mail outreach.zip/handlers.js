/**
 * HANDLERS — the HTTPS endpoints the review-email buttons point at.
 *
 * Every action is protected by an HMAC token bound to draftId + action
 * + expiry, so the links are useless to anyone without REVIEW_SECRET.
 */

import CONFIG from "../config.js";
import { verifyToken, signToken, tokenExpiry, logEvent, escapeHtml } from "./util.js";
import { regenerateEmail, finaliseBody } from "./generate.js";
import { sendProspectEmail, sendReviewEmail } from "./mailer.js";
import { modifyFormHtml, resultPage, dashboardHtml, reviewDigestHtml } from "./templates.js";

const html = (body, status = 200) =>
  new Response(body, { status, headers: { "Content-Type": "text/html; charset=utf-8" } });

async function loadDraft(env, id) {
  return env.DB.prepare(
    `SELECT d.*, c.name AS company_name, c.contact_email, c.website,
            c.city, c.sector, c.description, c.id AS cid
       FROM drafts d JOIN companies c ON c.id = d.company_id
      WHERE d.id = ?`
  )
    .bind(id)
    .first();
}

async function guard(env, url, action) {
  const id = url.searchParams.get("id");
  const token = url.searchParams.get("token");
  if (!id || !token) return { error: html(resultPage("Invalid link", "Missing parameters.", "err"), 400) };

  const valid = await verifyToken(env.REVIEW_SECRET, id, action, token);
  if (!valid) {
    return {
      error: html(
        resultPage("Link expired or invalid", "Request a fresh review email, or use the dashboard.", "err"),
        403
      ),
    };
  }

  const draft = await loadDraft(env, id);
  if (!draft) return { error: html(resultPage("Not found", "That draft no longer exists.", "err"), 404) };

  return { draft, id, token };
}

/* ── APPROVE ─────────────────────────────────────────────────────── */

export async function handleApprove(request, env) {
  const url = new URL(request.url);
  const g = await guard(env, url, "approve");
  if (g.error) return g.error;
  const { draft } = g;

  if (draft.status === "sent") {
    return html(resultPage("Already sent", `This email already went to ${escapeHtml(draft.contact_email)}.`, "warn"));
  }
  if (draft.status === "denied") {
    return html(resultPage("Already denied", "This draft was previously denied.", "warn"));
  }
  if (!draft.contact_email) {
    return html(resultPage("No recipient", "No contact email on record for this company.", "err"), 400);
  }

  const result = await sendProspectEmail(env.RESEND_API_KEY, {
    to: draft.contact_email,
    subject: draft.subject,
    text: finaliseBody(draft.body),
  });

  if (!result.ok) {
    await env.DB.prepare(`UPDATE drafts SET status='failed', error=? WHERE id=?`)
      .bind(result.error, draft.id)
      .run();
    await logEvent(env.DB, "draft", draft.id, "send_failed", "reviewer", result.error);
    return html(resultPage("Send failed", escapeHtml(result.error), "err"), 502);
  }

  await env.DB.batch([
    env.DB.prepare(
      `UPDATE drafts
          SET status='sent', provider_id=?, reviewed_at=datetime('now'), sent_at=datetime('now')
        WHERE id=?`
    ).bind(result.id, draft.id),
    env.DB.prepare(
      `UPDATE companies
          SET status='contacted', last_contacted_at=datetime('now'), updated_at=datetime('now')
        WHERE id=?`
    ).bind(draft.cid),
  ]);

  await logEvent(env.DB, "draft", draft.id, "approved_and_sent", "reviewer", {
    to: draft.contact_email,
  });

  return html(
    resultPage(
      "Sent",
      `Email delivered to <strong>${escapeHtml(draft.contact_email)}</strong><br>` +
        `<span style="color:#94a3b8;">${escapeHtml(draft.company_name)}</span>`,
      "ok"
    )
  );
}

/* ── DENY ────────────────────────────────────────────────────────── */

export async function handleDeny(request, env) {
  const url = new URL(request.url);
  const g = await guard(env, url, "deny");
  if (g.error) return g.error;
  const { draft } = g;

  if (draft.status === "sent") {
    return html(resultPage("Already sent", "This email has already gone out and cannot be denied.", "warn"));
  }

  await env.DB.batch([
    env.DB.prepare(
      `UPDATE drafts SET status='denied', reviewed_at=datetime('now') WHERE id=?`
    ).bind(draft.id),
    env.DB.prepare(
      `UPDATE companies SET status='denied', updated_at=datetime('now') WHERE id=?`
    ).bind(draft.cid),
  ]);

  await logEvent(env.DB, "draft", draft.id, "denied", "reviewer", { company: draft.company_name });

  return html(
    resultPage(
      "Denied",
      `<strong>${escapeHtml(draft.company_name)}</strong> will not be contacted, ` +
        `and is excluded from future runs.`,
      "warn"
    )
  );
}

/* ── MODIFY (GET = form) ─────────────────────────────────────────── */

export async function handleModifyForm(request, env) {
  const url = new URL(request.url);
  const g = await guard(env, url, "modify");
  if (g.error) return g.error;

  return html(
    modifyFormHtml({
      draft: g.draft,
      company: { name: g.draft.company_name, contact_email: g.draft.contact_email },
      token: g.token,
      baseUrl: (env.PUBLIC_BASE_URL || "").replace(/\/$/, ""),
    })
  );
}

/* ── MODIFY (POST = save) ────────────────────────────────────────── */

export async function handleModifySubmit(request, env) {
  const form = await request.formData();
  const id = form.get("id");
  const token = form.get("token");
  const action = form.get("action") || "save";

  if (!(await verifyToken(env.REVIEW_SECRET, id, "modify", token))) {
    return html(resultPage("Link expired or invalid", "Please request a fresh review email.", "err"), 403);
  }

  const draft = await loadDraft(env, id);
  if (!draft) return html(resultPage("Not found", "That draft no longer exists.", "err"), 404);

  let subject = (form.get("subject") || draft.subject).trim();
  let body = (form.get("body") || draft.body).trim();
  const instructions = (form.get("instructions") || "").trim();

  // AI rewrite takes precedence over manual edits
  if (instructions) {
    const regenerated = await regenerateEmail(
      env.AI,
      {
        name: draft.company_name,
        city: draft.city,
        sector: draft.sector,
        website: draft.website,
        description: draft.description,
      },
      { subject: draft.subject, body: draft.body },
      instructions
    );
    subject = regenerated.subject;
    body = regenerated.body;
  }

  await env.DB.prepare(
    `UPDATE drafts
        SET subject=?, body=?, revision=revision+1,
            reviewer_note=?, status='pending_review', reviewed_at=datetime('now')
      WHERE id=?`
  )
    .bind(subject, body, instructions || "manual edit", id)
    .run();

  await logEvent(env.DB, "draft", id, "modified", "reviewer", {
    mode: instructions ? "ai_rewrite" : "manual",
  });

  // Send immediately if requested
  if (action === "save_and_send") {
    if (!draft.contact_email) {
      return html(resultPage("No recipient", "No contact email on record.", "err"), 400);
    }
    const result = await sendProspectEmail(env.RESEND_API_KEY, {
      to: draft.contact_email,
      subject,
      text: finaliseBody(body),
    });
    if (!result.ok) {
      return html(resultPage("Send failed", escapeHtml(result.error), "err"), 502);
    }
    await env.DB.batch([
      env.DB.prepare(
        `UPDATE drafts SET status='sent', provider_id=?, sent_at=datetime('now') WHERE id=?`
      ).bind(result.id, id),
      env.DB.prepare(
        `UPDATE companies SET status='contacted', last_contacted_at=datetime('now') WHERE id=?`
      ).bind(draft.cid),
    ]);
    await logEvent(env.DB, "draft", id, "modified_and_sent", "reviewer", null);
    return html(
      resultPage("Sent", `Revised email delivered to <strong>${escapeHtml(draft.contact_email)}</strong>.`, "ok")
    );
  }

  // Otherwise re-issue the review email for this single draft
  const baseUrl = (env.PUBLIC_BASE_URL || "").replace(/\/$/, "");
  const exp = tokenExpiry();
  const [tA, tM, tD] = await Promise.all([
    signToken(env.REVIEW_SECRET, id, "approve", exp),
    signToken(env.REVIEW_SECRET, id, "modify", exp),
    signToken(env.REVIEW_SECRET, id, "deny", exp),
  ]);

  const digest = reviewDigestHtml({
    batchId: `${draft.batch_id}-rev${draft.revision + 1}`,
    baseUrl,
    items: [
      {
        draft: { ...draft, subject, body, revision: draft.revision + 1 },
        company: {
          name: draft.company_name,
          website: draft.website,
          contact_email: draft.contact_email,
          city: draft.city,
          sector: draft.sector,
        },
        score: "—",
        links: {
          approve: `${baseUrl}/review/approve?id=${id}&token=${tA}`,
          modify: `${baseUrl}/review/modify?id=${id}&token=${tM}`,
          deny: `${baseUrl}/review/deny?id=${id}&token=${tD}`,
        },
      },
    ],
  });

  await sendReviewEmail(env.RESEND_API_KEY, {
    subject: `Neurosaur — revised draft for ${draft.company_name}`,
    html: digest,
  });

  return html(
    resultPage(
      "Saved",
      `Revision ${draft.revision + 1} saved. A fresh review email has been sent to ` +
        `<strong>${escapeHtml(CONFIG.review.inbox)}</strong>.`,
      "ok"
    )
  );
}

/* ── DASHBOARD ───────────────────────────────────────────────────── */

export async function handleDashboard(request, env) {
  const { results } = await env.DB.prepare(
    `SELECT c.name, d.status, d.subject, d.created_at
       FROM drafts d JOIN companies c ON c.id = d.company_id
      ORDER BY d.created_at DESC LIMIT 100`
  ).all();
  return html(dashboardHtml(results || []));
}

/* ── SEED (one-time bulk import) ─────────────────────────────────── */

export async function handleSeed(request, env) {
  if (request.headers.get("X-Admin-Token") !== env.REVIEW_SECRET) {
    return new Response("Unauthorized", { status: 401 });
  }

  let list;
  try {
    list = await request.json();
  } catch {
    return new Response("Body must be a JSON array of companies", { status: 400 });
  }
  if (!Array.isArray(list)) return new Response("Expected a JSON array", { status: 400 });

  let inserted = 0,
    skipped = 0;

  for (const c of list) {
    if (!c.name) continue;
    let domain = null;
    try {
      domain = c.website ? new URL(c.website).hostname.replace(/^www\./, "").toLowerCase() : null;
    } catch {
      /* leave null */
    }
    try {
      await env.DB.prepare(
        `INSERT INTO companies (name, website, domain, city, sector, status)
         VALUES (?, ?, ?, ?, ?, 'new')`
      )
        .bind(
          c.name,
          c.website || null,
          domain,
          c.city || CONFIG.targeting.city,
          c.sector || null
        )
        .run();
      inserted++;
    } catch {
      skipped++; // duplicate domain
    }
  }

  return Response.json({ inserted, skipped, total: list.length });
}
