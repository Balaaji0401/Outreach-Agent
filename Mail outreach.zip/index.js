/**
 * NEUROSAUR OUTREACH ENGINE — entry point
 *
 *   scheduled()  → daily candidate discovery + draft generation + review email
 *   fetch()      → approve / modify / deny endpoints, dashboard, seed, health
 */

import { runDailyPipeline } from "./pipeline.js";
import {
  handleApprove,
  handleDeny,
  handleModifyForm,
  handleModifySubmit,
  handleDashboard,
  handleSeed,
} from "./handlers.js";

export default {
  /* ── CRON ──────────────────────────────────────────────────────── */
  async scheduled(event, env, ctx) {
    ctx.waitUntil(
      runDailyPipeline(env)
        .then((s) => console.log("pipeline complete:", JSON.stringify(s)))
        .catch((e) => console.error("pipeline failed:", e.stack || e.message))
    );
  },

  /* ── HTTP ──────────────────────────────────────────────────────── */
  async fetch(request, env) {
    const url = new URL(request.url);
    const { pathname } = url;
    const method = request.method;

    try {
      if (pathname === "/health") {
        return Response.json({ ok: true, service: "neurosaur-outreach" });
      }

      if (pathname === "/review/approve" && method === "GET") {
        return handleApprove(request, env);
      }

      if (pathname === "/review/deny" && method === "GET") {
        return handleDeny(request, env);
      }

      if (pathname === "/review/modify") {
        return method === "POST"
          ? handleModifySubmit(request, env)
          : handleModifyForm(request, env);
      }

      if (pathname === "/dashboard" && method === "GET") {
        return handleDashboard(request, env);
      }

      if (pathname === "/admin/seed" && method === "POST") {
        return handleSeed(request, env);
      }

      // Manual trigger for testing — same auth as seed
      if (pathname === "/admin/run" && method === "POST") {
        if (request.headers.get("X-Admin-Token") !== env.REVIEW_SECRET) {
          return new Response("Unauthorized", { status: 401 });
        }
        const summary = await runDailyPipeline(env);
        return Response.json(summary);
      }

      return new Response("Not found", { status: 404 });
    } catch (e) {
      console.error("request failed:", e.stack || e.message);
      return new Response("Internal error", { status: 500 });
    }
  },
};
