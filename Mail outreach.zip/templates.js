/** HTML templates — review digest email, modify form, confirmation pages. */

import CONFIG from "../config.js";
import { escapeHtml } from "./util.js";

const BRAND = "#071d2e";
const ACCENT = "#0e7490";

/* ── daily review digest ─────────────────────────────────────────── */

export function reviewDigestHtml({ batchId, items, baseUrl }) {
  const cards = items
    .map((it) => {
      const { draft, company, links, score } = it;
      return `
<tr><td style="padding:0 0 28px 0;">
  <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #dbe2ea;border-radius:8px;background:#ffffff;">
    <tr><td style="padding:18px 20px;border-bottom:1px solid #eef2f6;">
      <div style="font:600 17px/1.3 Arial,sans-serif;color:${BRAND};">
        ${escapeHtml(company.name)}
      </div>
      <div style="font:13px/1.5 Arial,sans-serif;color:#5b6b7c;margin-top:5px;">
        ${escapeHtml(company.sector || "Manufacturing")} ·
        ${escapeHtml(company.city || "Chennai")} ·
        score <strong style="color:${ACCENT};">${score}</strong>
      </div>
      <div style="font:13px/1.5 Arial,sans-serif;margin-top:5px;">
        <a href="${escapeHtml(company.website || "#")}" style="color:${ACCENT};">${escapeHtml(company.website || "")}</a>
        &nbsp;→&nbsp; <strong>${escapeHtml(company.contact_email || "no email")}</strong>
      </div>
    </td></tr>

    <tr><td style="padding:16px 20px;">
      <div style="font:11px/1 Arial,sans-serif;color:#8a97a6;letter-spacing:.6px;text-transform:uppercase;">Subject</div>
      <div style="font:600 15px/1.4 Arial,sans-serif;color:#1a2733;margin:6px 0 16px;">
        ${escapeHtml(draft.subject)}
      </div>
      <div style="font:11px/1 Arial,sans-serif;color:#8a97a6;letter-spacing:.6px;text-transform:uppercase;">Body</div>
      <div style="font:14px/1.65 Arial,sans-serif;color:#2b3a47;white-space:pre-wrap;margin-top:6px;background:#f8fafc;padding:14px;border-radius:6px;">${escapeHtml(draft.body)}</div>
    </td></tr>

    <tr><td style="padding:0 20px 20px;">
      <table cellpadding="0" cellspacing="0"><tr>
        <td style="padding-right:10px;">
          <a href="${links.approve}" style="display:inline-block;background:#15803d;color:#fff;font:600 14px Arial,sans-serif;padding:11px 22px;border-radius:6px;text-decoration:none;">Approve &amp; Send</a>
        </td>
        <td style="padding-right:10px;">
          <a href="${links.modify}" style="display:inline-block;background:#b45309;color:#fff;font:600 14px Arial,sans-serif;padding:11px 22px;border-radius:6px;text-decoration:none;">Modify</a>
        </td>
        <td>
          <a href="${links.deny}" style="display:inline-block;background:#9f1239;color:#fff;font:600 14px Arial,sans-serif;padding:11px 22px;border-radius:6px;text-decoration:none;">Deny</a>
        </td>
      </tr></table>
    </td></tr>
  </table>
</td></tr>`;
    })
    .join("");

  return `<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#eef2f6;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#eef2f6;padding:26px 12px;">
<tr><td align="center">
  <table width="640" cellpadding="0" cellspacing="0" style="max-width:640px;">
    <tr><td style="padding:0 0 22px;">
      <div style="font:700 21px/1.3 Arial,sans-serif;color:${BRAND};">Neurosaur — daily outreach review</div>
      <div style="font:13px/1.5 Arial,sans-serif;color:#5b6b7c;margin-top:6px;">
        ${items.length} candidate${items.length === 1 ? "" : "s"} · batch ${escapeHtml(batchId)} ·
        links valid ${CONFIG.review.linkValidHours}h
      </div>
    </td></tr>
    ${cards}
    <tr><td style="padding:6px 4px 0;">
      <div style="font:12px/1.6 Arial,sans-serif;color:#8a97a6;">
        Approve sends immediately to the prospect. Modify opens an editor and returns the draft for review.
        Deny blocks this company permanently.<br>
        <a href="${baseUrl}/dashboard" style="color:${ACCENT};">Open dashboard</a>
      </div>
    </td></tr>
  </table>
</td></tr></table>
</body></html>`;
}

/* ── modify form ─────────────────────────────────────────────────── */

export function modifyFormHtml({ draft, company, token, baseUrl }) {
  return page(
    "Modify draft",
    `
<h1 style="font:700 22px/1.3 Arial,sans-serif;color:${BRAND};margin:0 0 6px;">Modify draft</h1>
<p style="font:14px/1.6 Arial,sans-serif;color:#5b6b7c;margin:0 0 22px;">
  ${escapeHtml(company.name)} · ${escapeHtml(company.contact_email || "no email")} · revision ${draft.revision}
</p>

<form method="POST" action="${baseUrl}/review/modify">
  <input type="hidden" name="id" value="${draft.id}">
  <input type="hidden" name="token" value="${escapeHtml(token)}">

  <label style="display:block;font:600 12px Arial,sans-serif;color:#5b6b7c;text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px;">Subject</label>
  <input name="subject" value="${escapeHtml(draft.subject)}"
    style="width:100%;box-sizing:border-box;font:15px Arial,sans-serif;padding:11px;border:1px solid #cbd5e1;border-radius:6px;margin-bottom:20px;">

  <label style="display:block;font:600 12px Arial,sans-serif;color:#5b6b7c;text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px;">Body</label>
  <textarea name="body" rows="14"
    style="width:100%;box-sizing:border-box;font:14px/1.6 Arial,sans-serif;padding:11px;border:1px solid #cbd5e1;border-radius:6px;margin-bottom:24px;">${escapeHtml(draft.body)}</textarea>

  <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px;margin-bottom:24px;">
    <label style="display:block;font:600 12px Arial,sans-serif;color:#5b6b7c;text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px;">Or let the AI rewrite it</label>
    <p style="font:13px/1.5 Arial,sans-serif;color:#64748b;margin:0 0 10px;">
      Describe what to change and the engine will regenerate. This overrides your edits above.
    </p>
    <textarea name="instructions" rows="3" placeholder="e.g. make it shorter, mention predictive maintenance, less formal"
      style="width:100%;box-sizing:border-box;font:14px Arial,sans-serif;padding:11px;border:1px solid #cbd5e1;border-radius:6px;"></textarea>
  </div>

  <button type="submit" name="action" value="save"
    style="background:${ACCENT};color:#fff;font:600 15px Arial,sans-serif;padding:13px 26px;border:0;border-radius:6px;cursor:pointer;">
    Save &amp; resubmit for review
  </button>
  <button type="submit" name="action" value="save_and_send"
    style="background:#15803d;color:#fff;font:600 15px Arial,sans-serif;padding:13px 26px;border:0;border-radius:6px;cursor:pointer;margin-left:10px;">
    Save &amp; send now
  </button>
</form>`
  );
}

/* ── result pages ────────────────────────────────────────────────── */

export function resultPage(title, message, tone = "ok") {
  const colour = tone === "ok" ? "#15803d" : tone === "warn" ? "#b45309" : "#9f1239";
  return page(
    title,
    `<div style="text-align:center;padding:40px 0;">
       <div style="font:700 24px Arial,sans-serif;color:${colour};margin-bottom:12px;">${escapeHtml(title)}</div>
       <div style="font:15px/1.7 Arial,sans-serif;color:#475569;">${message}</div>
     </div>`
  );
}

export function dashboardHtml(rows) {
  const body = rows.length
    ? `<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font:13px Arial,sans-serif;">
        <tr style="background:#f1f5f9;">
          ${["Company", "Status", "Subject", "Created"].map(
            (h) => `<th align="left" style="padding:9px;border-bottom:1px solid #e2e8f0;color:#475569;">${h}</th>`
          ).join("")}
        </tr>
        ${rows
          .map(
            (r) => `<tr>
              <td style="padding:9px;border-bottom:1px solid #eef2f6;">${escapeHtml(r.name)}</td>
              <td style="padding:9px;border-bottom:1px solid #eef2f6;">${escapeHtml(r.status)}</td>
              <td style="padding:9px;border-bottom:1px solid #eef2f6;color:#64748b;">${escapeHtml((r.subject || "").slice(0, 60))}</td>
              <td style="padding:9px;border-bottom:1px solid #eef2f6;color:#94a3b8;">${escapeHtml(r.created_at)}</td>
            </tr>`
          )
          .join("")}
      </table>`
    : `<p style="font:14px Arial,sans-serif;color:#64748b;">No drafts yet.</p>`;

  return page("Outreach dashboard", `<h1 style="font:700 20px Arial,sans-serif;color:${BRAND};">Recent drafts</h1>${body}`);
}

function page(title, inner) {
  return `<!DOCTYPE html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(title)} · Neurosaur</title></head>
<body style="margin:0;background:#eef2f6;padding:30px 14px;">
<div style="max-width:720px;margin:0 auto;background:#fff;border-radius:10px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,.08);">
${inner}
</div></body></html>`;
}
