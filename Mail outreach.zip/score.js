/**
 * SCORE — opportunity scoring, 0-100. Higher = better prospect.
 *
 * Deliberately heuristic, not LLM-based. Workers AI free tier is
 * 10,000 neurons/day (~15-25 calls); we spend all of it on writing
 * good emails, not on classification a regex can do.
 *
 * Logic:
 *   start 50
 *   + confirms it's a manufacturer          → up to +30
 *   + has a usable published contact email  → +15
 *   + site has real substance               → +5
 *   - already talks about AI / Industry 4.0 → up to -45
 *   - looks like an IT/AI vendor themselves → disqualify
 */

import CONFIG from "../config.js";

function countMatches(haystack, needles) {
  const hits = [];
  for (const n of needles) {
    const term = n.toLowerCase();
    if (haystack.includes(term)) hits.push(n.trim());
  }
  return hits;
}

export function scoreCompany({ corpus, description, title, email }) {
  const text = ` ${(corpus || "") + " " + (description || "") + " " + (title || "")}`
    .toLowerCase()
    .replace(/\s+/g, " ");

  const detail = {};
  let score = 50;

  // ── disqualifiers ────────────────────────────────────────────────
  const excluded = countMatches(text, CONFIG.targeting.excludeKeywords);
  if (excluded.length) {
    return {
      score: 0,
      eligible: false,
      detail: { disqualified: true, reason: "appears to be an IT/AI vendor", excluded },
    };
  }

  // ── sector confirmation ──────────────────────────────────────────
  const sectorHits = countMatches(text, CONFIG.targeting.sectorKeywords);
  const sectorPoints = Math.min(30, sectorHits.length * 6);
  score += sectorPoints;
  detail.sectorHits = sectorHits.slice(0, 10);
  detail.sectorPoints = sectorPoints;

  if (sectorHits.length === 0) {
    return {
      score: 0,
      eligible: false,
      detail: { ...detail, disqualified: true, reason: "no manufacturing signal found" },
    };
  }

  // ── existing AI maturity (we want LOW) ───────────────────────────
  const aiHits = countMatches(text, CONFIG.targeting.aiMaturityKeywords);
  detail.aiHits = aiHits.slice(0, 10);

  // Hard cutoff: a company talking about AI this much is already mature.
  // They are not our audience — we train companies that are new to AI.
  if (aiHits.length >= CONFIG.targeting.aiMaturityCutoff) {
    return {
      score: 0,
      eligible: false,
      detail: {
        ...detail,
        disqualified: true,
        reason: `already AI-mature (${aiHits.length} AI signals on site)`,
      },
    };
  }

  const aiPenalty = Math.min(50, aiHits.length * 14);
  score -= aiPenalty;
  detail.aiPenalty = aiPenalty;

  // ── contactability ───────────────────────────────────────────────
  if (email) {
    score += 15;
    detail.hasEmail = true;
  } else {
    detail.hasEmail = false;
  }

  // ── site substance ───────────────────────────────────────────────
  if ((corpus || "").length > 3000) {
    score += 5;
    detail.substantialSite = true;
  }

  score = Math.max(0, Math.min(100, Math.round(score)));

  const eligible = score >= CONFIG.targeting.minimumScore && !!email;
  detail.finalScore = score;
  detail.eligible = eligible;
  if (!eligible && !email) detail.ineligibleReason = "no published contact email";
  else if (!eligible) detail.ineligibleReason = `score ${score} below minimum ${CONFIG.targeting.minimumScore}`;

  return { score, eligible, detail };
}
