/**
 * NEUROSAUR OUTREACH ENGINE — CONFIGURATION
 * ------------------------------------------------------------------
 * Every tunable value lives here. Change this file, redeploy, done.
 * No other file should need editing for routine changes.
 * ------------------------------------------------------------------
 */

export const CONFIG = {

  // ── WHO GETS WHAT ───────────────────────────────────────────────
  review: {
    // Internal reviewer inbox — receives the daily digest for approval
    inbox: "info@neurosaur.in",

    // Sender identity for the INTERNAL review mail
    fromEmail: "engine@neurosaur.in",
    fromName: "Neurosaur Outreach Engine",

    // Approval links expire after this many hours
    linkValidHours: 72,
  },

  outbound: {
    // Sender identity for the mail that goes to the PROSPECT
    fromEmail: "hello@neurosaur.in",
    fromName: "Neurosaur AI Academy",

    // Replies from prospects land here
    replyTo: "info@neurosaur.in",

    // Shown at the bottom of every prospect email (compliance)
    signatureBlock: [
      "Dr. Deepak K",
      "Neurosaur AI Academy",
      "+91 74010 40174 · neurosaur.in",
    ],

    // Required for legitimate cold outreach — do not remove
    unsubscribeText:
      "If you'd prefer not to hear from us, reply with 'UNSUBSCRIBE' and we'll remove you immediately.",

    postalAddress: "Neurosaur AI Academy, Chennai, Tamil Nadu, India",
  },


  // ── VOLUME & SCHEDULE ───────────────────────────────────────────
  pipeline: {
    // How many candidates to surface per run
    candidatesPerDay: 5,

    // Don't re-contact the same company within this many days
    recontactCooldownDays: 180,

    // Max companies to enrich per run (each = 1 website fetch)
    maxEnrichPerRun: 25,

    // Skip companies whose website fetch fails this many times
    maxEnrichAttempts: 3,
  },
  // NOTE: the actual cron time is set in wrangler.toml ("triggers.crons").
  //       Default there is 30 3 * * *  =  09:00 IST daily.


  // ── TARGETING ───────────────────────────────────────────────────
  targeting: {
    city: "Chennai",
    region: "Tamil Nadu",

    // Terms that CONFIRM this is a manufacturing business (adds score)
    sectorKeywords: [
      "manufacturing", "manufacturer", "factory", "plant", "production",
      "engineering", "fabrication", "machining", "assembly", "industrial",
      "auto components", "automotive", "castings", "forging", "moulding",
      "injection molding", "sheet metal", "cnc", "tooling", "die casting",
      "textiles", "spinning", "chemicals", "pharma", "packaging",
      "electronics", "pumps", "valves", "bearings", "iso 9001", "iatf",
    ],

    // Terms indicating EXISTING AI maturity (reduces score — we want low)
    aiMaturityKeywords: [
      "artificial intelligence", "machine learning", " ai ", "ai-powered",
      "ai powered", "data science", "data scientist", "deep learning",
      "predictive analytics", "predictive maintenance", "computer vision",
      "industry 4.0", "industry 4", "smart factory", "digital twin",
      "iot platform", "generative ai", "genai", "llm", "chatgpt",
      "digital transformation", "advanced analytics", "mlops",
    ],

    // Company is disqualified outright if any of these appear
    excludeKeywords: [
      "ai consulting", "ai solutions company", "software development company",
      "it services", "data analytics company", "machine learning company",
    ],

    // Hard disqualifier: if this many AI-maturity terms appear on their site,
    // they already do AI and are not our audience. Lower = stricter targeting.
    aiMaturityCutoff: 3,

    // Minimum opportunity score to be eligible for outreach (0-100)
    minimumScore: 55,
  },


  // ── WHAT WE SAY ─────────────────────────────────────────────────
  company: {
    name: "Neurosaur AI Academy",
    tagline: "Think · Build · Innovate",
    website: "https://neurosaur.in",

    positioning:
      "Neurosaur AI Academy delivers research-backed AI training, consulting and " +
      "implementation. We help people and organisations learn and use AI at work. " +
      "Programmes are delivered by trainers with experience across research, academia " +
      "and industry, led by Dr. Deepak K, a postdoctoral AI researcher with 10+ years " +
      "across AI research, academia and industry.",

    programs: [
      {
        name: "AI for Productivity",
        url: "https://neurosaur.in/ai-productivity.html",
        pitch:
          "Practical workshops that help every department — production, quality, " +
          "purchase, HR, finance — use Copilot, ChatGPT, Gemini and Claude responsibly " +
          "in daily work.",
      },
      {
        name: "AI for Profitability",
        url: "https://neurosaur.in/ai-profitability.html",
        pitch:
          "Advisory-led programmes that align AI adoption with measurable ROI — " +
          "identifying where AI reduces cost or improves throughput in the business.",
      },
      {
        name: "AI for Employability",
        url: "https://neurosaur.in/ai-employability.html",
        pitch:
          "Role-based pathways that take your engineering and technical teams from " +
          "first principles to production-ready AI skills.",
      },
    ],

    proofPoints: [
      "IES (consumer electronics) — embedded AI into production and operational " +
        "workflows to improve productivity and efficiency.",
      "Creams (bakery & retail) — deployed AI-powered workforce and sales monitoring " +
        "for real-time financial visibility.",
      "50+ roles upskilled through live, practitioner-led classes for working professionals.",
    ],

    // Low-friction call to action — better conversion than "book a call"
    primaryCTA: {
      label: "Free AI Readiness Assessment",
      url: "https://neurosaur.in/ai-readiness-assessment.html#assessment",
    },
  },


  // ── EMAIL GENERATION ────────────────────────────────────────────
  generation: {
    // Workers AI model. 8B keeps us inside the 10k neurons/day free tier.
    // Larger models (70B) will exhaust the daily allocation.
    model: "@cf/meta/llama-3.1-8b-instruct",

    maxTokens: 700,
    temperature: 0.7,

    // Hard rules the model must follow
    rules: [
      "Write in British/Indian business English. Plain, direct, no hype.",
      "Maximum 150 words in the body. Short paragraphs. No bullet lists.",
      "NEVER say or imply the company is behind, outdated, lacks AI, or is missing out.",
      "Open with something specific and factual about THEIR business.",
      "Name exactly ONE Neurosaur programme — the one that best fits them.",
      "Reference at most one proof point, only if genuinely relevant.",
      "End with a soft, low-commitment call to action.",
      "Do not invent facts, numbers, client names or claims.",
      "Do not use the words: revolutionise, cutting-edge, leverage, synergy, unlock, empower.",
      "No emojis. No exclamation marks.",
    ],

    subjectRules:
      "Maximum 8 words. Specific to their business. No colons, no clickbait, " +
      "no words like 'transform', 'revolutionise', 'unlock' or 'boost'.",
  },


  // ── SAFETY ──────────────────────────────────────────────────────
  safety: {
    // Global kill switch — set false to stop all outbound prospect sends.
    // Internal review mails still go out so you can see what WOULD send.
    sendingEnabled: true,

    // Never email these domains
    blockedDomains: [
      "gmail.com", "yahoo.com", "hotmail.com", "outlook.com",
      "rediffmail.com", "neurosaur.in",
    ],

    // Respect robots.txt when fetching company sites
    respectRobotsTxt: true,

    // User agent used when fetching prospect websites
    userAgent:
      "NeurosaurBot/1.0 (+https://neurosaur.in; research contact: info@neurosaur.in)",

    fetchTimeoutMs: 12000,
  },
};

export default CONFIG;
