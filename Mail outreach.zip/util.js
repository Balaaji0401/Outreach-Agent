/** Shared helpers. */

import CONFIG from "../config.js";

/* ── logging ─────────────────────────────────────────────────────── */

export async function logEvent(db, entityType, entityId, action, actor, detail) {
  try {
    await db
      .prepare(
        `INSERT INTO events (entity_type, entity_id, action, actor, detail)
         VALUES (?, ?, ?, ?, ?)`
      )
      .bind(
        entityType,
        entityId == null ? null : String(entityId),
        action,
        actor || "engine",
        typeof detail === "string" ? detail : JSON.stringify(detail ?? null)
      )
      .run();
  } catch (e) {
    console.error("logEvent failed:", e.message);
  }
}

/* ── signed action tokens ────────────────────────────────────────── */

/**
 * HMAC-SHA256 token binding draftId + action + expiry.
 * Prevents anyone without the secret from triggering an approval.
 */
export async function signToken(secret, draftId, action, expiresAt) {
  const payload = `${draftId}:${action}:${expiresAt}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  const hex = [...new Uint8Array(sig)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `${expiresAt}.${hex}`;
}

export async function verifyToken(secret, draftId, action, token) {
  if (!token || !token.includes(".")) return false;
  const [expiresAt] = token.split(".");
  if (Number(expiresAt) < Date.now()) return false;
  const expected = await signToken(secret, draftId, action, Number(expiresAt));
  // constant-time-ish comparison
  if (expected.length !== token.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) {
    diff |= expected.charCodeAt(i) ^ token.charCodeAt(i);
  }
  return diff === 0;
}

export function tokenExpiry() {
  return Date.now() + CONFIG.review.linkValidHours * 3600 * 1000;
}

/* ── html / text ─────────────────────────────────────────────────── */

/** Strip tags and collapse whitespace. Input is truncated to keep CPU low. */
export function htmlToText(html, maxChars = 120000) {
  const trimmed = html.length > maxChars ? html.slice(0, maxChars) : html;
  return trimmed
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&#?\w{2,8};/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export function domainOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return null;
  }
}

/* ── fetching ────────────────────────────────────────────────────── */

export async function safeFetch(url, timeoutMs = CONFIG.safety.fetchTimeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": CONFIG.safety.userAgent,
        Accept: "text/html,application/xhtml+xml",
      },
      redirect: "follow",
      cf: { cacheTtl: 3600, cacheEverything: true },
    });
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("html") && !ct.includes("text")) {
      return { ok: false, error: `unsupported content-type: ${ct}` };
    }
    return { ok: true, text: await res.text(), finalUrl: res.url };
  } catch (e) {
    return { ok: false, error: e.name === "AbortError" ? "timeout" : e.message };
  } finally {
    clearTimeout(timer);
  }
}

/** Minimal robots.txt check for our own user-agent path prefix rules. */
export async function robotsAllows(baseUrl, path = "/") {
  if (!CONFIG.safety.respectRobotsTxt) return true;
  try {
    const origin = new URL(baseUrl).origin;
    const res = await safeFetch(`${origin}/robots.txt`, 6000);
    if (!res.ok) return true; // no robots.txt = allowed
    const lines = res.text.split("\n").map((l) => l.trim().toLowerCase());
    let applies = false;
    const disallowed = [];
    for (const line of lines) {
      if (line.startsWith("user-agent:")) {
        const ua = line.split(":")[1].trim();
        applies = ua === "*" || ua.includes("neurosaur");
      } else if (applies && line.startsWith("disallow:")) {
        const p = line.split(":")[1].trim();
        if (p) disallowed.push(p);
      }
    }
    return !disallowed.some((p) => path.startsWith(p));
  } catch {
    return true;
  }
}

export function batchId() {
  return new Date().toISOString().slice(0, 19).replace(/[-:T]/g, "");
}
