/**
 * PIPELINE — the daily run.
 *
 *   1. enrich unprocessed companies (fetch site, extract email, score)
 *   2. pick the top N eligible, not-recently-contacted candidates
 *   3. generate one tailored email each
 *   4. store as drafts, build signed approve/modify/deny links
 *   5. send ONE digest to the reviewer inbox
 *
 * Nothing is sent to a prospect here. Sending only happens on approval.
 */

import CONFIG from "../config.js";
import { enrichCompany } from "./enrich.js";
import { scoreCompany } from "./score.js";
import { generateEmail } from "./generate.js";
import { sendReviewEmail } from "./mailer.js";
import { reviewDigestHtml } from "./templates.js";
import { logEvent, signToken, tokenExpiry, batchId, domainOf } from "./util.js";

/* ── step 1: enrichment ──────────────────────────────────────────── */

async function enrichPending(env) {
  const { results } = await env.DB.prepare(
    `SELECT * FROM companies
      WHERE status = 'new'
        AND enrich_attempts < ?
      ORDER BY created_at ASC
      LIMIT ?`
  )
    .bind(CONFIG.pipeline.maxEnrichAttempts, CONFIG.pipeline.maxEnrichPerRun)
    .all();

  let enriched = 0;

  for (const company of results || []) {
    const res = await enrichCompany(company);

    if (!res.ok) {
      await env.DB.prepare(
        `UPDATE companies
            SET enrich_attempts = enrich_attempts + 1,
                last_error = ?,
                updated_at = datetime('now')
          WHERE id = ?`
      )
        .bind(res.error, company.id)
        .run();
      continue;
    }

    const { score, eligible, detail } = scoreCompany(res);

    await env.DB.prepare(
      `UPDATE companies
          SET description = ?, contact_email = COALESCE(?, contact_email),
              ai_score = ?, score_detail = ?, status = ?,
              enrich_attempts = enrich_attempts + 1,
              last_error = NULL, updated_at = datetime('now')
        WHERE id = ?`
    )
      .bind(
        res.description,
        res.email || null,
        score,
        JSON.stringify(detail),
        eligible ? "enriched" : "ineligible",
        company.id
      )
      .run();

    enriched++;
    await logEvent(env.DB, "company", company.id, eligible ? "enriched" : "ineligible", "engine", {
      score,
      email: res.email || null,
    });
  }

  return enriched;
}

/* ── step 2: selection ───────────────────────────────────────────── */

async function selectCandidates(env, limit) {
  const { results } = await env.DB.prepare(
    `SELECT * FROM companies
      WHERE status = 'enriched'
        AND contact_email IS NOT NULL
        AND ai_score >= ?
        AND (last_contacted_at IS NULL
             OR julianday('now') - julianday(last_contacted_at) > ?)
      ORDER BY ai_score DESC, created_at ASC
      LIMIT ?`
  )
    .bind(CONFIG.targeting.minimumScore, CONFIG.pipeline.recontactCooldownDays, limit)
    .all();

  return results || [];
}

/* ── main ────────────────────────────────────────────────────────── */

export async function runDailyPipeline(env) {
  const runId = batchId();
  const summary = { runId, enriched: 0, selected: 0, drafted: 0, errors: [] };

  await logEvent(env.DB, "run", runId, "started", "engine", null);

  try {
    summary.enriched = await enrichPending(env);
  } catch (e) {
    summary.errors.push(`enrichment: ${e.message}`);
  }

  const candidates = await selectCandidates(env, CONFIG.pipeline.candidatesPerDay);
  summary.selected = candidates.length;

  if (!candidates.length) {
    await logEvent(env.DB, "run", runId, "no_candidates", "engine", summary);
    return summary;
  }

  const baseUrl = (env.PUBLIC_BASE_URL || "").replace(/\/$/, "");
  const items = [];

  for (const company of candidates) {
    try {
      const draft = await generateEmail(env.AI, company);

      const inserted = await env.DB.prepare(
        `INSERT INTO drafts (company_id, batch_id, subject, body, status)
         VALUES (?, ?, ?, ?, 'pending_review')
         RETURNING id, subject, body, revision`
      )
        .bind(company.id, runId, draft.subject, draft.body)
        .first();

      // Reserve the company so it can't be picked again next run
      await env.DB.prepare(
        `UPDATE companies SET status = 'queued', updated_at = datetime('now') WHERE id = ?`
      )
        .bind(company.id)
        .run();

      const exp = tokenExpiry();
      const [tApprove, tModify, tDeny] = await Promise.all([
        signToken(env.REVIEW_SECRET, inserted.id, "approve", exp),
        signToken(env.REVIEW_SECRET, inserted.id, "modify", exp),
        signToken(env.REVIEW_SECRET, inserted.id, "deny", exp),
      ]);

      items.push({
        draft: inserted,
        company,
        score: company.ai_score,
        links: {
          approve: `${baseUrl}/review/approve?id=${inserted.id}&token=${tApprove}`,
          modify: `${baseUrl}/review/modify?id=${inserted.id}&token=${tModify}`,
          deny: `${baseUrl}/review/deny?id=${inserted.id}&token=${tDeny}`,
        },
      });

      summary.drafted++;
      await logEvent(env.DB, "draft", inserted.id, "generated", "engine", {
        company: company.name,
        fallback: !!draft.fallback,
      });
    } catch (e) {
      summary.errors.push(`${company.name}: ${e.message}`);
    }
  }

  if (items.length) {
    const html = reviewDigestHtml({ batchId: runId, items, baseUrl });
    const sent = await sendReviewEmail(env.RESEND_API_KEY, {
      subject: `Neurosaur — ${items.length} outreach draft${items.length === 1 ? "" : "s"} for review`,
      html,
    });
    if (!sent.ok) summary.errors.push(`review email: ${sent.error}`);
  }

  await logEvent(env.DB, "run", runId, "completed", "engine", summary);
  return summary;
}
