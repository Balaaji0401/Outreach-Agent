-- NEUROSAUR OUTREACH ENGINE — D1 SCHEMA
-- Apply with:  npx wrangler d1 execute neurosaur_outreach --file=./schema.sql --remote

DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS drafts;
DROP TABLE IF EXISTS companies;

CREATE TABLE companies (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  name              TEXT NOT NULL,
  website           TEXT,
  domain            TEXT,
  city              TEXT,
  sector            TEXT,
  contact_email     TEXT,
  description       TEXT,          -- extracted from their website
  ai_score          INTEGER,       -- opportunity score 0-100 (higher = better prospect)
  score_detail      TEXT,          -- JSON explaining the score
  status            TEXT NOT NULL DEFAULT 'new',
                                   -- new | enriched | ineligible | queued
                                   -- | contacted | denied | unsubscribed | bounced
  enrich_attempts   INTEGER NOT NULL DEFAULT 0,
  last_error        TEXT,
  last_contacted_at TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE UNIQUE INDEX idx_companies_domain ON companies(domain) WHERE domain IS NOT NULL;
CREATE INDEX idx_companies_status       ON companies(status);
CREATE INDEX idx_companies_score        ON companies(ai_score DESC);

CREATE TABLE drafts (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id     INTEGER NOT NULL REFERENCES companies(id),
  batch_id       TEXT NOT NULL,        -- groups the 5 drafts of one run
  subject        TEXT NOT NULL,
  body           TEXT NOT NULL,
  revision       INTEGER NOT NULL DEFAULT 1,
  status         TEXT NOT NULL DEFAULT 'pending_review',
                                        -- pending_review | approved | denied
                                        -- | sent | failed
  reviewer_note  TEXT,
  provider_id    TEXT,                  -- Resend message id once sent
  error          TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  reviewed_at    TEXT,
  sent_at        TEXT
);

CREATE INDEX idx_drafts_status  ON drafts(status);
CREATE INDEX idx_drafts_batch   ON drafts(batch_id);
CREATE INDEX idx_drafts_company ON drafts(company_id);

CREATE TABLE events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,    -- company | draft | run
  entity_id   TEXT,
  action      TEXT NOT NULL,
  actor       TEXT,             -- 'engine' | 'reviewer'
  detail      TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_events_entity  ON events(entity_type, entity_id);
CREATE INDEX idx_events_created ON events(created_at DESC);
