/**
 * GENERATE — write one tailored outreach email using Workers AI.
 *
 * Budget note: free tier is 10,000 neurons/day. Llama-3.1-8B at ~700
 * output tokens costs roughly 500-700 neurons per call, so 5 emails/day
 * ≈ 3,000 neurons. Comfortable. Do NOT switch to a 70B model without
 * moving to Workers Paid.
 */

import CONFIG from "../config.js";

function buildSystemPrompt() {
  const { company, generation } = CONFIG;

  const programs = company.programs
    .map((p) => `- ${p.name}: ${p.pitch} (${p.url})`)
    .join("\n");

  const proof = company.proofPoints.map((p) => `- ${p}`).join("\n");

  return `You write short, respectful B2B outreach emails for ${company.name}.

ABOUT US
${company.positioning}

OUR THREE PROGRAMMES
${programs}

PROOF POINTS (use at most one, only if genuinely relevant)
${proof}

PRIMARY CALL TO ACTION
${company.primaryCTA.label} — ${company.primaryCTA.url}

RULES — follow every one
${generation.rules.map((r) => `- ${r}`).join("\n")}

SUBJECT LINE RULES
${generation.subjectRules}

OUTPUT FORMAT
Return ONLY valid JSON, no markdown fences, no commentary:
{"subject": "...", "body": "..."}

The body must be plain text with \\n\\n between paragraphs.
Do not include a signature, greeting sign-off, or unsubscribe line —
those are appended automatically.`;
}

function buildUserPrompt(company) {
  return `Write an outreach email to this company.

COMPANY NAME: ${company.name}
LOCATION: ${company.city || CONFIG.targeting.city}
SECTOR: ${company.sector || "manufacturing"}
WEBSITE: ${company.website || "n/a"}

WHAT THEIR WEBSITE SAYS ABOUT THEM:
"""
${(company.description || "").slice(0, 900)}
"""

Write the email now. Return JSON only.`;
}

/** Robustly pull JSON out of a model response. */
function parseModelJson(raw) {
  if (!raw) return null;
  let s = String(raw).trim();
  s = s.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const start = s.indexOf("{");
  const end = s.lastIndexOf("}");
  if (start === -1 || end === -1) return null;
  try {
    const obj = JSON.parse(s.slice(start, end + 1));
    if (!obj.subject || !obj.body) return null;
    return { subject: String(obj.subject).trim(), body: String(obj.body).trim() };
  } catch {
    return null;
  }
}

/** Deterministic fallback if the model misbehaves — never blocks the pipeline. */
function fallbackEmail(company) {
  const prog = CONFIG.company.programs[0];
  return {
    subject: `AI training for your ${company.city || "Chennai"} team`,
    body:
      `Hello,\n\n` +
      `I came across ${company.name} and wanted to introduce ${CONFIG.company.name}. ` +
      `We run practical AI training for manufacturing teams across Tamil Nadu.\n\n` +
      `Our ${prog.name} programme is usually the best starting point — ${prog.pitch}\n\n` +
      `If it's useful, we offer a free AI readiness assessment that takes about ten minutes ` +
      `and gives you a view of where AI could realistically help: ${CONFIG.company.primaryCTA.url}\n\n` +
      `Happy to answer any questions.`,
    fallback: true,
  };
}

export async function generateEmail(ai, company) {
  try {
    const response = await ai.run(CONFIG.generation.model, {
      messages: [
        { role: "system", content: buildSystemPrompt() },
        { role: "user", content: buildUserPrompt(company) },
      ],
      max_tokens: CONFIG.generation.maxTokens,
      temperature: CONFIG.generation.temperature,
    });

    const parsed = parseModelJson(response?.response ?? response);
    if (parsed) return { ...parsed, fallback: false };

    console.warn(`Model returned unparseable output for ${company.name}; using fallback`);
    return fallbackEmail(company);
  } catch (e) {
    console.error(`Workers AI failed for ${company.name}: ${e.message}`);
    return { ...fallbackEmail(company), error: e.message };
  }
}

/** Regenerate with reviewer instructions applied. */
export async function regenerateEmail(ai, company, currentDraft, instructions) {
  try {
    const response = await ai.run(CONFIG.generation.model, {
      messages: [
        { role: "system", content: buildSystemPrompt() },
        { role: "user", content: buildUserPrompt(company) },
        {
          role: "assistant",
          content: JSON.stringify({
            subject: currentDraft.subject,
            body: currentDraft.body,
          }),
        },
        {
          role: "user",
          content:
            `Revise the email using this feedback from our reviewer:\n\n` +
            `"""${instructions}"""\n\n` +
            `Keep all original rules. Return JSON only.`,
        },
      ],
      max_tokens: CONFIG.generation.maxTokens,
      temperature: CONFIG.generation.temperature,
    });

    const parsed = parseModelJson(response?.response ?? response);
    return parsed || { subject: currentDraft.subject, body: currentDraft.body, fallback: true };
  } catch (e) {
    console.error(`Regeneration failed: ${e.message}`);
    return { subject: currentDraft.subject, body: currentDraft.body, error: e.message };
  }
}

/** Append signature, CTA and unsubscribe to the model's body. */
export function finaliseBody(body) {
  const { outbound, company } = CONFIG;
  return [
    body.trim(),
    "",
    `${company.primaryCTA.label}: ${company.primaryCTA.url}`,
    "",
    "--",
    ...outbound.signatureBlock,
    "",
    outbound.unsubscribeText,
    outbound.postalAddress,
  ].join("\n");
}
